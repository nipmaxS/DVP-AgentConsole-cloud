/**
 * Created by Veery Team on 9/20/2016.
 */
agentApp.factory("reservedTicket", function () {

    var key="";
    var session_obj={};

    return {
        key: key,
        session_obj:session_obj
    }





});