/**
 * Created by Veery Team on 9/8/2016.
 */

agentApp.controller('notificationCenterCtrl', function ($scope, $http) {


});
